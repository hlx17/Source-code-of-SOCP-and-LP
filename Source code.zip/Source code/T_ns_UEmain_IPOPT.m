clear; clc; close all
tic
%% input parameter
% [ num_link , num_node , num_od , demand_od ] = deal( 76 , 24 , 4 , [5,10,5,10] );
[ num_link , num_node ] = deal( 76 , 24 );
% [ num_link , num_node ] = deal( 943 , 222 );
% demand=zeros(24,24);demand(1,20)=5;demand(2,13)=10;demand(1,19)=5;demand(2,23)=10;
demand = csvread('L:\201902\input_data1\input_od1.csv',0,0,[0,0,23,23]);
% demand(1,19:24)=[5,10,5,10,5,10];
%10
% demand(5:24,:)=0; demand(1:4,1:20)=0; demand(4,24)=0;
%20
demand(6:24,:)=0; demand(1:5,1:19)=0; demand(6,23:24)=[1,1];
%30
% demand(7:24,:)=0; demand(1:6,1:17)=0; demand(6,18)=0;
%38
% demand(8:24,:)=0; demand(1:7,1:17)=0;
demand = demand./9;
r_demand = find(demand~=0);
num_od = length(r_demand);
od = zeros(num_od,2);
demand_od = zeros(1,num_od);
c_od = 0;
for i = 1:num_node
    for j = 1:num_node
        if demand(i,j)~=0
            c_od = c_od+1;
            od(c_od,: ) = [i,j];
            demand_od(c_od) = demand(i,j);
        end
    end
end
% creat  basic matrix
%[ link , od , node_link , OD ] = input_data( num_link , num_node , num_od );
[ link , node_link , OD ] = input_data( num_link , num_node , num_od , od );
%% initialization
% initial link flow and link cost
link_flow = zeros( 1 , num_link );
link_cost = cost_link( link , link_flow );
% let the incidence element be the link length
A = zeros(num_node,num_node);
for i = 1:num_link
    A( link(i,1) , link(i,2) ) = link_cost(i);
end
% let the incidence element be inf if there is no link
for i = 1:num_node
    for j = 1:num_node
        if i~=j && A(i,j)==0
            A(i,j) = inf;
        end
    end
end
% initial path and path cost
%[ path_V  , time_cost_V ] = T_ns_path( node_link , OD , link_cost );
[ path_V , time_cost_V ] = T_ns_pathdij( OD , link_cost , A , link );
% set a cell array to present the feasible path of each od
whole_path = cell( 1 , num_od );
for j = 1:num_od
    whole_path{ j } = path_V{1}( : , j );
end
%% get the UE and find the new feasiable path
alltime=0;
for i = 1:250
    [ link_flow , link_cost , time_cost , sum_linkcost , result ] = T_ns_UE_ip( whole_path , link , demand_od );
    alltime=alltime+result.solvertime;
    t1 = clock;
    %[ c_path_V  , c_time_cost_V ] = T_ns_path( node_link , OD , link_cost );
    [ c_path_V , c_time_cost_V ] = T_ns_pathdij( OD , link_cost , A , link );
    stop = 0;
    % check if there has a new feasible path for each od
    for j = 1:num_od
        %% whether there has shorter path
        [ ~ , num_path_V ] = size( whole_path{j} );
        flag_V=0;
        % whether current path had been adopted
        for k = 1:num_path_V
            if whole_path{j}( :,k) == c_path_V{1}( :, j)
                flag_V = 1;
                stop = stop + 1;
            end
        end
        % append new feasible path if current path hadn't been adopted
        if flag_V == 0
            whole_path{j} = [ whole_path{j} , c_path_V{1}( :, j) ];
        end
    end
    t2 = clock;
    alltime = alltime + etime(t2,t1);
    % break if no feasible path for any od pair
    if stop == num_od
        break
    end
end
toc
result.solvertime