function [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link )
num_link = size(link,1);
first_n=100;
link_flow = cell(num_link,1);
for i = 1:num_link
    link_flow{i} = linspace( 0 , real_max(i) , first_n );
    link_flow{i}(first_n+1) = real_max(i)+1;
end
linkflow_xikema = cell(num_link,1);
n = zeros(1,num_link);
failed=0;
for i = 1:num_link
    flag=2;
    x1=link_flow{i}(1); x2=link_flow{i}(2);
    linkflow_xikema{i}=0;
    ganma = link(i,3)/100*0.15;
    while x2~=link_flow{i}(first_n+1)
        k = ganma * (x2^5-x1^5) / (x2-x1);
        b = ganma * ( x2*x1^5 - x1*x2^5 ) / ( x2-x1 );
        x = sqrt(sqrt(k/5/ganma));
        y = k*x+b-ganma * x^5;
        if y<=error
            flag=flag+1;
            x2=link_flow{i}(flag);
        else
            x3=x1;
            x4=x2;
            x1=link_flow{i}(flag-1);
            x2=link_flow{i}(flag);
            if x3==x1 && x4==x2
                failed=1;
                break
            end
            linkflow_xikema{i} = [ linkflow_xikema{i} , x1 ];
        end
        if failed==1
            break
        end
    end
    linkflow_xikema{i} = [ linkflow_xikema{i} , real_max(i) , flow_max ];
    n(i)=length(linkflow_xikema{i});
    linkflow_xikema{i} = linkflow_xikema{i}.*link(i,4);
end
end