clear; clc; close all
tic
%% input parameter
% [ num_link , num_node ] = deal( 943 , 222 );
% [ num_link , num_node , num_zone ] = deal( 76 , 24 , 24 );
[ num_link , num_node , num_zone ] = deal( 138 , 38 , 38 );
%%  creat break points
n=100*ones(num_link,1); flow_max=120; linkflow_xikema = cell(num_link,1);
for i = 1:num_link
    linkflow_xikema{i} = linspace( 0 , flow_max , n(1) );
end
%%
demand = csvread('L:\201902\input_data1\input_od_n38.csv',0,0,[0,0,num_zone-1,num_zone-1]); 
demand = demand./4;
% demand = csvread('L:\201902\input_data1\input_testod7.csv',0,0,[0,0,num_node-1,num_node-1]);
% demand = demand.*1.5;
r_demand = find(demand~=0);
num_od = length(r_demand);
od = zeros(num_od,2);
demand_od = zeros(1,num_od);
c_od = 0;
for i = 1:num_zone
    for j = 1:num_zone
        if demand(i,j)~=0
            c_od = c_od+1;
            od(c_od,: ) = [i,j];
            demand_od(c_od) = demand(i,j);
        end
    end
end
% creat  basic matrix
[ link , OD , node_link ] = input_data( num_link , num_node , num_od , od );
%% standard
% real_lp = csvread('L:\201902\input_data1\input_nlp.csv',1,1,[1,1,1,num_link]);
% real_max = (real_lp+0.5)./link(:,4)';
% [ flow_max , error ] = deal( 12 , 0.005 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
%% double
% real_lp = csvread('L:\201902\input_data1\input_nlp.csv',2,1,[2,1,2,num_link]);
% real_max = (real_lp+0.5)./link(:,4)';
% [ flow_max , error ] = deal( 12 , 0.005 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
%% half
% real_lp = csvread('L:\201902\input_data1\input_nlp.csv',3,1,[3,1,3,num_link]);
% real_max = (real_lp+0.1)./link(:,4)';
% [ flow_max , error ] = deal( 3 , 0.0001 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
%% Beijing standard
% real_lp = csvread('L:\201902\input_data1\input_bjnlp.csv',1,1,[1,1,1,num_link]);
% real_max = (real_lp+0.5)./link(:,4)';
% [ flow_max , error ] = deal( 10 , 0.0004 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
% n_mod=687;
% n(n_mod)=10; linkflow_xikema{n_mod}(10)=linkflow_xikema{n_mod}(3); linkflow_xikema{n_mod}(1:9)=linspace(0,linkflow_xikema{n_mod}(2)-0.6,9);
%% Beijing * 0.75
% real_lp = csvread('L:\201902\input_data1\input_bjnlp.csv',2,1,[2,1,2,num_link]);
% real_max = (real_lp+0.5)./link(:,4)';
% [ flow_max , error ] = deal( 8 , 0.0001 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
%% Beijing * 1.5
% real_lp = csvread('L:\201902\input_data1\input_bjnlp.csv',3,1,[3,1,3,num_link]);
% real_max = (real_lp+0.5)./link(:,4)';
% [ flow_max , error ] = deal( 15 , 0.003 );
% [ n , linkflow_xikema , failed ] = non_uniforms( flow_max , real_max , error , link );
%% initialization
% initial link flow and link cost
link_flow = zeros( 1 , num_link );
link_cost = cost_link( link , link_flow );
% let the incidence element be the link length
A = zeros(num_node,num_node);
for i = 1:num_link
    A( link(i,1) , link(i,2) ) = link_cost(i);
end
% let the incidence element be inf if there is no link
for i = 1:num_node
    for j = 1:num_node
        if i~=j && A(i,j)==0
            A(i,j) = inf;
        end
    end
end
% initial path and path cost
% [ path_V  , time_cost_V , btime ] = T_ns_path( node_link , OD , link_cost );
[ path_V , time_cost_V ] = T_ns_pathdij( OD , link_cost , A , link );
% set a cell array to present the feasible path of each od
whole_path = cell( 1 , num_od );
for j = 1:num_od
    whole_path{ j } = path_V{1}( : , j );
end
%% get the UE and find the new feasiable path
for i = 1:1000
    [ link_flow , link_cost , time_cost , sum_linkcost , uetime ] = T_ns_UE_LPs( whole_path , link , demand_od , n , linkflow_xikema );
%     [ c_path_V  , c_time_cost_V , mlptime ] = T_ns_path( node_link , OD , link_cost );
    [ c_path_V , c_time_cost_V ] = T_ns_pathdij( OD , link_cost , A , link );
    stop = 0;
    num_path_GV = zeros(1,num_od);
    % check if there has a new feasible path for each od
    for j = 1:num_od
        %% whether there has shorter path
        %% whether there has shorter path
        flag_GV=0;
        [ ~ , num_path_GV(j) ] = size( whole_path{j} );
        % whether current path had been adopted
        for k = 1:num_path_GV(j)
            if whole_path{j}( :,k) == c_path_V{1}( :, j)
                flag_GV = 1;
                stop = stop + 1;
                break
            end
        end
        % append new feasible path if current path hadn't been adopted
        if flag_GV == 0
            whole_path{j} = [ whole_path{j} , c_path_V{1}( :, j) ];
        end
    end
    % break if no feasible path for any od pair
    if stop == num_od
        break
    end
end
x = link_flow';
link(:,6) = x;