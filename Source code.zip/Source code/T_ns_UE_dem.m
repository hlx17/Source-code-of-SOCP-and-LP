function [ link_cost ] = T_ns_UE_dem( num_node , num_link , num_zone )
%% demand
switch num_node
    case(24)
demand = csvread('L:\201902\input_data1\input_od1.csv',0,0,[0,0,num_node-1,num_node-1]);
% demand = csvread('L:\201902\input_data1\input_testod7.csv',0,0,[0,0,num_node-1,num_node-1]);
first_node = num_zone+1;
demand = csvread('L:\201902\input_data1\input_od3_2.csv',0,0,[0,0,num_zone-1,num_zone-1]);
demand( first_node : first_node+num_zone-1 , first_node : first_node+num_zone-1 ) = demand;
demand(1:num_zone,1:num_zone) = 0;
[x_demand,y_demand] = size(demand);
demand = demand./300;
r_demand = find(demand~=0);
num_od = length(r_demand);
od = zeros(num_od,2);
demand_od = zeros(1,num_od);
c_od = 0;
for i = 1:x_demand
    for j = 1:y_demand
        if demand(i,j)~=0
            c_od = c_od+1;
            od(c_od,: ) = [i,j];
            demand_od(c_od) = demand(i,j);
        end
    end
end
end