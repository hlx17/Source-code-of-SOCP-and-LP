function [ link_flow , link_cost , time_cost , sum_linkcost ,result ] = T_ns_UE_ip( whole_path , link , demand_od )
% calculate UE problem with curent path and link cost
% get the number of od and link
[ ~ , num_od ] = size( whole_path );
[ num_link , ~ ] = size( link );
% calculate the number of path of each od
num_path_V = zeros( 1 , num_od );
for j = 1:num_od
    [ ~ , num_path_V( j ) ] = size( whole_path{j} );
end
% calculate total number of path
total_num_path = sum( num_path_V );
% set a vector to pin the start of each od path
pin = ones( 1 , num_od+1 );
for j = 2:num_od+1
    pin( j ) = pin( j-1 ) + num_path_V( j-1 );
end
% set the variable of path flow
concrete_pathflow = sdpvar( 1 , total_num_path );
c_pf_0 = zeros(1,total_num_path);
od_demand = sdpvar( 1 , num_od );
% calculate the total path flow of each od
for j = 1:num_od
    od_demand( j ) = sum(  concrete_pathflow( pin(j):pin(j+1)-1 )  );
    c_pf_0(pin(j)) = demand_od(j);
end
% set a new path matrix in order to calculate link flow easily
new_path{1} = zeros( num_link , total_num_path );
for j = 1:num_od
    new_path{1}( : , pin(j):pin(j+1)-1 ) = whole_path{j};
end
% calculate the link flow
linkflow = concrete_pathflow * new_path{1}';
% constraints
C = [od_demand == demand_od
    concrete_pathflow>=0];
% function
integral_linkcost = int_cost_link_ip( link , linkflow );
sumlinkcost=sum( integral_linkcost(:) );
% solution
ops = sdpsettings('solver','IPOPT','verbose',2);
% ops = sdpsettings('solver','ipopt','verbose',2,'usex0',c_pf_0);
result  = optimize(C , sumlinkcost , ops);
if result.problem== 0
    link_flow = value(linkflow);
    sum_linkcost = value(sumlinkcost);
else
    disp('�������г���');
end
% calculate the cost of each link
link_cost = cost_link( link , link_flow );
% set a cell array to present the time cost of each path of each od
time_cost = cell(1,num_od);
for j = 1:num_od
    time_cost{j} = link_cost * whole_path{j};
end
end