node = csvread('L:\201902\input_data1\input_node2.csv',1,3,[1,3,222,4]);
link = csvread('L:\201902\input_data1\input_parameter2.csv',1,1,[1,1,943,4]);
node_x = node( : ,1)*50;
node_y = node( : ,2)*50;
from_x = node_x( link ( : ,1) );
from_y = node_y( link ( : ,1) );
to_x = node_x( link ( : ,2) );
to_y = node_y( link ( : ,2) );
type=link_flow./link(:,4)';
wid=1;le=zeros(4,1);
for i = 1:943
    if ismember(0,le)
        if type(i)<1.2 && le(1)==0
            le(1)=i;
        elseif type(i)<1.5 && le(2)==0
            le(2)=i;
        elseif type(i)<1.8 && le(3)==0
            le(3)=i;
        elseif le(4)==0
            le(4)=i;
        end
    end
end
plot ( [from_x(le(1));to_x(le(1))] , [from_y(le(1));to_y(le(1))] , '-g','LineWidth',wid )
hold on
plot ( [from_x(le(2));to_x(le(2))] , [from_y(le(2));to_y(le(2))] , '-b','LineWidth',wid )
hold on
plot ( [from_x(le(3));to_x(le(3))] , [from_y(le(3));to_y(le(3))] , '-y','LineWidth',wid )
hold on
plot ( [from_x(le(4));to_x(le(4))] , [from_y(le(4));to_y(le(4))] , '-r','LineWidth',wid )
hold on
for i = 1:943
    x = [ from_x( i ) ; to_x( i ) ];
    y = [ from_y( i ) ; to_y( i ) ];
    if type(i)<1.2
        if i~=le(1)
            plot ( x , y, '-g','LineWidth',wid )
            hold on
        end
    elseif type(i)<1.5
        if i~=le(2)
            plot( x , y , '-b','LineWidth' , wid )
            hold on
        end
    elseif type(i)<1.8
        if i~=le(3)
            plot( x , y ,'-y','LineWidth' , wid )
            hold on
        end
    else
        if i~=le(4)
            plot( x , y ,'-r','LineWidth' , wid )
            hold on
        end
    end
end
legend('0~1.2','1.2~1.6','1.6~2.0','2.0~3.5');
%     if i<223
%         n = num2str(i);
%         text( node_x( i )+0.05 , node_y( i )+0.2 ,n);
%     end
% axis( [0,450000,0,550000] );
% xlabel('longitude')
% ylabel('latitude')
title('Traffic Condition')
text(5826,2000,'x_a/c_a')