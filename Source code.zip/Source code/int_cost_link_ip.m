function [ integral_linkcost ] = int_cost_link_ip( link , link_flow )
%   ��·����ʻʱ��
integral_linkcost = link( :,3 )./100 .* ( link_flow'+0.03.*(link_flow').^5./link(:,4).^4 );
% integral_linkcost = link( :,3 )./100 .* ( link_flow'+0.2.*(link_flow').^5./link(:,4).^4 );
integral_linkcost = integral_linkcost';
end