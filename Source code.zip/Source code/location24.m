node = csvread('L:\201902\input_data\input_node.csv',1,3,[1,3,24,4]);
link = csvread('L:\201902\input_data1\input_parameter1.csv',1,1,[1,1,76,2]);
node_x = node( : ,1);
node_y = node( : ,2);
from_x = node_x( link ( : ,1) );
from_y = node_y( link ( : ,1) );
to_x = node_x( link ( : ,2) );
to_y = node_y( link ( : ,2) );
for i = 1:76
    x = [ from_x( i ) ; to_x( i ) ];
    y = [ from_y( i ) ; to_y( i ) ];
    plot ( x , y, '-k' )
    hold on
    if i<25
        n = num2str(i);
        text( node_x( i )+5000 , node_y( i )+10000 ,n);
    end
end
axis( [0,450000,0,550000] );
xlabel('������')
ylabel('������')
title('��ͨ����ͼ')