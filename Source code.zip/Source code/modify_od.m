%% modify the format of od
num_zone=38; num_space=2; num_z=(38-rem(38,5))/5+1; num_s=num_space+num_z;
od =csvread('l:\201902\input_data1\input_3_1od.csv',0,0,[0,0,num_zone*num_s-num_space-1,4]);
new_od=zeros(num_zone,num_zone);
for i = 1:num_zone
    for j = 1:num_zone
        w=rem(j,5);
        if w==0
            w=5;
        end
        l=(j-w)/5;
        new_od(i,j)=od(num_s*(i-1)+1+l,w);
    end
end
od=zeros(num_zone,num_zone);
for i = 1:num_zone
    flag=1;
    for j = 1:num_zone
        if i~=j
            od(i,j)=new_od(i,flag);
            flag=flag+1;
        end
    end
end