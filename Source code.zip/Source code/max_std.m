% en=abs(link_flow(1,:)-link_flow(2,:));
% mreen=en./link_flow(2,:);
% mre=max(en./link_flow(2,:))
% s = std(en)

for i = 2:176
    dev=cachef(i,:)-cachef(i-1,:);
    for j = 1:560
        if cachef(i-1,j)>0.001
            dev(j) = dev(j)/cachef(i-1,j);
        end
    end
    if dev<=0.05
        break
    end
end