function [ n , linkflow_xikema , failed ] = non_uniform( flow_max , error , link )
num_link = size(link,1);
first_n=100;
link_flow = linspace( 0 , flow_max , first_n );
link_flow(first_n+1) = flow_max+1;
linkflow_xikema = cell(num_link,1);
n = zeros(1,num_link);
failed=0;
% for i = 1:num_link
for i = 1:num_link
    flag=2;
    x1=link_flow(1); x2=link_flow(2);
    linkflow_xikema{i}=0;
    ganma = link(i,3)/100*0.15/link(:,4)^4;
    while x2~=link_flow(first_n+1)
        k = ganma * (x2^5-x1^5) / (x2-x1);
        b = ganma * ( x2*x1^5 - x1*x2^5 ) / ( x2-x1 );
        x = sqrt(sqrt(k/5/ganma));
        y = k*x+b-ganma * x^5;
        if y<=error
            flag=flag+1;
            x2=link_flow(flag);
        else
            x3=x1;
            x4=x2;
            x1=link_flow(flag-1);
            x2=link_flow(flag);
            if x3==x1 && x4==x2
                failed=1;
                break
            end
            linkflow_xikema{i} = [ linkflow_xikema{i} , x1 ];
        end
    end
    if failed==1
        break
    end
    if ismember(flow_max,linkflow_xikema{i})
    else
        linkflow_xikema{i} = [linkflow_xikema{i} , flow_max];
    end
    n(i)=length(linkflow_xikema{i});
end
end