%% delete the non-exist link
num_all_link = 2184;
b_link =csvread('D:\hlx17\201902\input_data1\input_berlin_link.csv',1,1,[1,1,num_all_link,5]);
link=zeros(1,5);
flag=1;
for i = 1:num_all_link
    if b_link(i,5)~=0
        link(flag,:)=b_link(i,:);
        flag=flag+1;
    end
end