clear; clc; close all
tic
%% input parameter
[ num_link , num_node , num_zone ] = deal( 76 , 24 ,24 );
% [ num_link , num_node , num_zone ] = deal( 943 , 222 ,222 );
% [ num_link , num_node , num_zone ] = deal( 914 , 416 , 38 );
% [ num_link , num_node , num_zone ] = deal( 583 , 398 , 36 );
% [ num_link , num_node , num_zone ] = deal( 451 , 352 , 38 );
% [ num_link , num_node , num_zone ] = deal( 560 , 361 , 26 );
% [ num_link , num_node , num_zone ] = deal( 138 , 38 , 0 );
% creat  basic matrix
%[ link , od , node_link , OD ] = input_data( num_link , num_node , num_od );
[ link , OD , node_link ] = input_data( num_link , num_node , num_od , od );
%% initialization
% initial link flow and link cost
link_flow = zeros( 1 , num_link );
link_cost = cost_link( link , link_flow );
% let the incidence element be the link length
A = zeros(num_node,num_node);
for i = 1:num_link
    A( link(i,1) , link(i,2) ) = link_cost(i);
end
% let the incidence element be inf if there is no link
for i = 1:num_node
    for j = 1:num_node
        if i~=j && A(i,j)==0
            A(i,j) = inf;
        end
    end
end
% initial path and path cost
% [ path_V  , time_cost_V , mlptime ] = T_ns_path( node_link , OD , link_cost );
[ path_V , time_cost_V , mlptime ] = T_ns_pathdij( OD , link_cost , A , link  ); 
% set a cell array to present the feasible path of each od
whole_path = cell( 1 , num_od );
for j = 1:num_od
    whole_path{ j } = path_V{1}( : , j );
end
%% get the UE and find the new feasiable path
alltime=0; btime=mlptime;
for i = 1:100
    [ link_flow , link_cost , time_cost , sum_linkcost , result ] = T_ns_UE_SOCP( whole_path , link , demand_od );
    alltime=alltime+result.solvertime;
%     [ c_path_V  , c_time_cost_V , mlptime ] = T_ns_path( node_link , OD , link_cost );
    [ c_path_V , c_time_cost_V , mlptime ] = T_ns_pathdij( OD , link_cost , A , link );
    btime = btime + mlptime;
    t1 = clock;
    stop = 0;
    % check if there has a new feasible path for each od
    for j = 1:num_od
        %% whether there has shorter path
        if c_time_cost_V(j) < min(time_cost{j})
            whole_path{j} = [ whole_path{j} , c_path_V{1}( :, j) ];
        else
            stop=stop+1;
        end
    end
    t2 = clock;
    alltime = alltime + etime(t2,t1);
    % break if no feasible path for any od pair
    if stop == num_od
        break
    end
end
toc