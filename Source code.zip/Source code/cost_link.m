function [ link_cost ] = cost_link( link , link_flow )
%  calculate the cost of each link
link_cost = link( :,3)./100 .* (1+0.15.*(link_flow'./link(:,4)).^4);
% link_cost = link( :,3)./100 .* (1+(link_flow'./link(:,4)).^4);
link_cost = link_cost';
end