function [ link_flow , link_cost , time_cost , sum_linkcost ,result ] = T_ns_UE_SOCP( whole_path , link , demand_od )
% calculate UE problem with curent path and link cost
% get the number of od and link
[ ~ , num_od ] = size(whole_path);
[ num_link , ~ ] = size(link);
% calculate the number of path of each od
num_path_V = zeros( 1 , num_od );
for j = 1:num_od
    [ ~ , num_path_V( j ) ] = size( whole_path{j} );
end
% calculate total number of path
total_num_path = sum( num_path_V );
% set a vector to pin the start of each od path
pin = ones( 1 , num_od+1 );
for j = 2:num_od+1
    pin( j ) = sum( num_path_V(1:j-1) ) + 1;
end
% set the variable of path flow
concrete_pathflow = sdpvar( 1 , total_num_path );
upper_y = sdpvar( 1 , num_link );
cplex_t = sdpvar( 6 , num_link );
od_pathflow = sdpvar( 1 , num_od );
% calculate the total path flow of each od
for j = 1:num_od
    od_pathflow( j ) = sum(  concrete_pathflow( pin(j):pin(j+1)-1 )  );
end
% set a new path matrix in order to calculate link flow easily
new_path{1} = zeros( num_link , total_num_path );
for j = 1:num_od
    new_path{1}( : , pin(j):pin(j+1)-1 ) = whole_path{j};
end
% calculate the link flow
linkflow = concrete_pathflow * new_path{1}';
% constraints
C = [od_pathflow == demand_od
    concrete_pathflow>=0
    cplex_t>=0];
for i = 1:num_link
    c = [cone( [2*linkflow(i),cplex_t(5,i)-cplex_t(6,i)] , cplex_t(5,i)+cplex_t(6,i) )
        cone( [2*cplex_t(5,i),cplex_t(1,i)-cplex_t(2,i)] , cplex_t(1,i)+cplex_t(2,i) )
        cone( [2*cplex_t(6,i),cplex_t(3,i)-cplex_t(4,i)] , cplex_t(3,i)+cplex_t(4,i) )
        cplex_t(1,i) <= linkflow(i)
        cone( [2*cplex_t(2,i),linkflow(i)-1] , linkflow(i)+1 )
        cone( [2*cplex_t(3,i),upper_y(i)-1] , upper_y(i)+1 )
        cplex_t(4,i) <= 1];
    C = [C,c];
end
% function
integral_linkcost = int_cost_link_SOCP( link , linkflow , upper_y );
sumlinkcost=sum( integral_linkcost(:) );
% solution
ops = sdpsettings('solver','cplex','verbose',2);
result  = optimize(C , sumlinkcost , ops);
if result.problem== 0
    link_flow = value(linkflow);
    sum_linkcost = value(sumlinkcost);
else
    disp('�������г���');
end
% calculate the cost of each link
link_cost = cost_link( link , link_flow );
% set a cell array to present the time cost of each path of each od
time_cost = cell(1,num_od);
for j = 1:num_od
    time_cost{j} = link_cost * whole_path{j};
end
end