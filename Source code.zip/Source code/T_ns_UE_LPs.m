function [ link_flow , link_cost , time_cost , sum_linkcost , uetime ] = T_ns_UE_LPs( whole_path , link , demand_od , n , linkflow_xikema )
% calculate UE problem with curent path and link cost
% get the number of od and link
[ ~ , num_od ] = size(whole_path);
[ num_link , ~ ] = size(link);
% calculate the number of path of each od
num_path_V = zeros( 1 , num_od );
for j = 1:num_od
    [ ~ , num_path_V( j ) ] = size( whole_path{j} );
end
% calculate total number of path
total_num_path = sum( num_path_V );
% set a vector to pin the start of each od path
pin = ones( 1 , num_od+1 );
for j = 2:num_od+1
    pin( j ) = sum( num_path_V(1:j-1) ) + 1;
end
% set the variable of path flow
concrete_pathflow = sdpvar( 1 , total_num_path );
od_pathflow = sdpvar( 1 , num_od );
% calculate the total path flow of each od
for j = 1:num_od
    od_pathflow( j ) = sum(  concrete_pathflow( pin(j):pin(j+1)-1 )  );
end
% set a new path matrix in order to calculate link flow easily
new_path{1} = zeros( num_link , total_num_path );
for j = 1:num_od
    new_path{1}( : , pin(j):pin(j+1)-1 ) = whole_path{j};
end
% calculate the link flow
linkflow = concrete_pathflow * new_path{1}';
% constraints
C = [od_pathflow == demand_od
    concrete_pathflow>=0];
%% LP approach
% set a vector to pin the xikema of each od pair
pinxi = ones( 1, num_link+1 );
for i = 1:num_link
    pinxi(i+1) = sum(n(1:i)) + 1;
end
% LP Approximation's variable
xikema = sdpvar( pinxi(num_link+1)-1 , 1 , 'full' );
c = xikema>=0;
C = [C,c];
% upper_y = sumlinkflow.^5;
upper_y = sdpvar( 1, num_link , 'full' );
for i = 1:num_link
    upper_y(i) = linkflow_xikema{i}.^5 * xikema(pinxi(i):pinxi(i+1)-1);
end
for i = 1:num_link
    c = [sum(xikema(pinxi(i):pinxi(i+1)-1))==1
        linkflow(i) == linkflow_xikema{i} * xikema(pinxi(i):pinxi(i+1)-1)];
    C = [C,c];
end
%%
% function
integral_linkcost = int_cost_link_SOCP( link , linkflow , upper_y );
sumlinkcost=sum( integral_linkcost(:) );
% solution
ops = sdpsettings('solver','cplex','verbose',2);
result  = optimize(C , sumlinkcost , ops);
if result.problem== 0
    link_flow = value(linkflow);
    sum_linkcost = value(sumlinkcost);
    uetime = result.solvertime;
else
    disp('�������г���');
end
% calculate the cost of each link
link_cost = cost_link( link , link_flow );
% set a cell array to present the time cost of each path of each od
time_cost = cell(1,num_od);
for j = 1:num_od
    time_cost{j} = link_cost * whole_path{j};
end
end