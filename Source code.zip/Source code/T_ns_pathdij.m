function [ path_V , time_cost_V , mlptime ] = T_ns_pathdij( OD , link_cost , A , link )
%% Dijkstra
% calculate the shortest path and minimun time cost for each od
% get the number of link and od
t1 = clock;
[ ~ , num_link ] = size( link_cost );
[ ~ , num_od ] = size( OD );
% set the initial path matrix and time cost matrix
path_V = cell(1);
path_V{1} = zeros(num_link,num_od);
%% let the incidence element be the link length
% set the initial path matrix and time cost matrix
for i = 1:num_link
    A( link(i,1) , link(i,2) ) = link_cost(i);
end
for i = 1:num_od
    sb=find( OD(:,i)==1 );
    db=find( OD(:,i)==-1 );
    path = LeBlanc_dijkstra( A , sb , db );
    len_path = length(path)-1;
    for j = 1:len_path
        for k = 1:num_link
            if path(j:j+1) == link(k,1:2)
                path_V{1}(k,i)=1;
                break
            end
        end
    end
end
time_cost_V = link_cost * path_V{1};
t2 = clock;
mlptime=etime(t2,t1);
end