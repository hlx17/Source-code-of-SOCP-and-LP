clear; clc; close all
tic
%% input parameter
% input the number of link, node and od
[ num_link , num_node ] = deal( 76 , 24 );
% demand(i,j) denote trips of node i to node j
% demand = csvread('L:\201902\input_data\input_od.csv',1,0,[1,0,num_node,num_node-1]);
% demand(13:24,:)=0;
% demand(1:12,1:12)=0;
% demand(10:24,:)=0;
% demand(1:9,1:15)=0;
% demand=zeros(24,24);
% demand(1,20)=5; demand(2,13)=10; demand(1,19)=5; demand(2,23)=10;
demand = csvread('L:\201902\input_data1\input_od1.csv',0,0,[0,0,23,23]);
demand = demand*0.8;
r_demand = find(demand~=0);
num_od = length(r_demand);
od = zeros(num_od,2);
demand_od = zeros(1,num_od);
c_od = 0;
for i = 1:24
    for j = 1:24
        if demand(i,j)~=0
            c_od = c_od+1;
            od(c_od,: ) = [i,j];
            demand_od(c_od) = demand(i,j);
        end
    end
end
% creat  basic matrix
[ link , node_link , OD ] = input_data( num_link , num_node , num_od , od );
%% initialization
% initial link flow and link cost
link_flow = zeros( 1 , num_link );
link_cost = cost_link( link , link_flow );
% initial path and path cost
[ path_V , time_cost_V ] = T_ns_path( node_link , OD , link_cost );
% set a cell array to present the feasible path of each od
whole_path = cell( 1 , num_od );
for j = 1:num_od
    whole_path{ j } = path_V{1}( : , j );
end
%[ link_flow , link_cost , time_cost , sum_linkcost ,result ] = T_ns_UE_LP( whole_path , link , demand_od );
%% get the UE and find the new feasiable path
for i = 1:1000
    % solve UE problem with current feasible path
    tic
    [ link_flow , link_cost , time_cost , sum_linkcost ] = T_ns_UE_ip( whole_path , link , demand_od );
    toc
    % calculate the shortest path and cost of each od and period
    [ c_path_V  , c_time_cost_V ] = T_ns_path( node_link , OD , link_cost );
    stop = 0;
    % check if there has a new feasible path for each od
    for j = 1:num_od
        %% whether there has shorter path
        if c_time_cost_V(j) <= time_cost{j}(1) + 0.001
            [ ~ , num_path_V ] = size( whole_path{j} );
            flag_V=0;
            % whether current path had been adopted
            for k = 1:num_path_V
                if whole_path{j}( :,k) == c_path_V{1}( :, j)
                    flag_V = 1;
                    stop = stop + 1;
                end
            end
            % append new feasible path if current path hadn't been adopted
            if flag_V == 0
                whole_path{j} = [ whole_path{j} , c_path_V{1}( :, j) ];
            end
        end
    end
    % break if no feasible path for any od pair
    if stop == num_od
        break
    end
end
toc