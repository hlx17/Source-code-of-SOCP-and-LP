function [ inte_link_cost ] = int_cost_link_SOCP( link , link_flow , upper_y )
%   ��·����ʻʱ��
inte_link_cost = link( :,3 )./100 .* (link_flow'+0.03.*(upper_y')./link(:,4).^4);
% inte_link_cost = link( :,3 )./100 .* (link_flow'+0.2.*(upper_y')./link(:,4).^4);
inte_link_cost = inte_link_cost';
end