function [ path_V , time_cost_V , btime ] = T_ns_path( node_link , OD , link_cost )
% calculate the shortest path and minimun time cost for each od
% get the number of link and od
[ ~ , num_link ] = size( node_link );
[ ~ , num_od ] = size( OD );
% set the initial path matrix and time cost matrix
path_V = cell(1);
time_cost_V = zeros(1,num_od);
btime = 0;
%% calculate the shortest path and minimum time cost for each od
for j = 1:num_od
    pathV = binvar( num_link , 1 );
    % constraints
    C = node_link * pathV == OD( : , j );
    % function
    timecost_V = link_cost * pathV;
    % solution
    ops = sdpsettings('solver','cbc','verbose',2);
    result  = optimize( C , timecost_V , ops );
    if result.problem== 0
        path_V{1}( : , j ) = value( pathV );
        time_cost_V( j ) = value( timecost_V );
        btime = btime+result.solvertime;
    else
        disp('�������г���');
    end
end
end