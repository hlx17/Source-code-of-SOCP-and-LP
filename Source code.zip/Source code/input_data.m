function [ link , OD ,node_link ] = input_data( num_link , num_node , num_od , od )
%[ link , node_link , OD ] = input_data( num_link , num_node , num_od , od )
%[ link , od , node_link , OD ] = input_data( num_link , num_node , num_od )
% creat the input data
% input the parameter of link and od
switch num_node
    case(4)
        link = csvread('L:\201902\input_data\input_parameter4.csv',1,1,[1,1,num_link,4]);
    case(24)
        link = csvread('L:\201902\input_data1\input_parameter1.csv',1,1,[1,1,num_link,4]);
    case(38)
        link = csvread('L:\201904\input\input_link_n38.csv',1,1,[1,1,num_link,5]);
    case(222)
        link = csvread('L:\201902\input_data1\input_parameter2.csv',1,1,[1,1,num_link,4]);
    case(416)
        link = csvread('L:\201902\input_data1\input_parameter3_1.csv',1,1,[1,1,num_link,4]);
        link(:,4) = link(:,4)./100;
    case(398)
        link = csvread('L:\201902\input_data1\input_parameter3_2.csv',1,1,[1,1,num_link,4]);
        link(:,4) = link(:,4)./100;        
    case(352)
        link = csvread('L:\201902\input_data1\input_parameter3_3.csv',1,1,[1,1,num_link,4]);
        link(:,4) = link(:,4)./100;
    case(361)
        link = csvread('L:\201902\input_data1\input_parameter3_4.csv',1,1,[1,1,num_link,4]);
        link(:,4) = link(:,4)./100;
end
%% creat node_link matrix
node_link = zeros( num_node , num_link );
for i = 1:num_link
    node_link( link( i , 1 ) , i ) = 1;
    node_link( link( i , 2 ) , i ) = -1;
end
%% creat OD matrix
OD = zeros(num_node , num_od);
for i = 1:num_od
    OD( od( i , 1) , i ) = 1;
    OD( od( i , 2 ) , i ) = -1;
end
end